
  # Create Interactive Webpage

  This is a code bundle for Create Interactive Webpage. The original project is available at https://www.figma.com/design/fsJjpsvJhbJNekpjpC1n48/Create-Interactive-Webpage.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  