import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { DashboardCircle } from './components/DashboardCircle';

export default function App() {
  const [demandValue, setDemandValue] = useState(92845);
  const [efficiencyValue, setEfficiencyValue] = useState(105);

  // Simulate real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setDemandValue(prev => {
        const variation = (Math.random() - 0.5) * 1000;
        return Math.max(90000, Math.min(95000, prev + variation));
      });
      
      setEfficiencyValue(prev => {
        const variation = (Math.random() - 0.5) * 10;
        return Math.max(95, Math.min(110, prev + variation));
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center p-8">
      {/* Background grid pattern */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, rgba(255,255,255,0.15) 1px, transparent 0)`,
          backgroundSize: '40px 40px',
        }}
      />
      
      {/* Main content */}
      <motion.div
        className="relative z-10 flex gap-16 items-center"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        {/* Current Demand Circle */}
        <DashboardCircle
          type="demand"
          value={demandValue}
          label="Current Demand"
          sublabel="Current Capacity"
          color="#00f5ff"
          glowColor="#00f5ff"
          progress={75}
        />

        {/* System Efficiency Circle */}
        <DashboardCircle
          type="efficiency"
          value={efficiencyValue}
          label="System Efficiency"
          sublabel="Predicted Demand Next 24 HRS"
          color="#ff8c42"
          glowColor="#ff8c42"
          progress={90}
        />
      </motion.div>

      {/* Floating particles effect */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-white rounded-full opacity-20"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [-20, -100, -20],
            opacity: [0.2, 0.8, 0.2],
          }}
          transition={{
            duration: 4 + Math.random() * 4,
            repeat: Infinity,
            delay: Math.random() * 4,
            ease: "easeInOut",
          }}
        />
      ))}

      {/* Interactive hint */}
      <motion.div
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-gray-500 text-sm"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 3, duration: 1 }}
      >
        Hover over the circles for interactive effects
      </motion.div>
    </div>
  );
}