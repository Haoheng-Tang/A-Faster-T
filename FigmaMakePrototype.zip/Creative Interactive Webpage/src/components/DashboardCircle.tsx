import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import { CircularProgress } from './CircularProgress';
import { TrendingUp, CheckCircle, Calendar, BarChart3 } from 'lucide-react';

interface DashboardCircleProps {
  type: 'demand' | 'efficiency';
  value: number;
  label: string;
  sublabel: string;
  color: string;
  glowColor: string;
  progress: number;
}

export function DashboardCircle({ 
  type, 
  value, 
  label, 
  sublabel, 
  color, 
  glowColor, 
  progress 
}: DashboardCircleProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [animatedValue, setAnimatedValue] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimatedValue(value);
    }, 500);
    return () => clearTimeout(timer);
  }, [value]);

  const formatValue = (val: number) => {
    if (type === 'demand') {
      return val.toLocaleString();
    }
    return `${val}%`;
  };

  const getIcon = () => {
    if (type === 'demand') {
      return <BarChart3 className="w-6 h-6" style={{ color }} />;
    }
    return <Calendar className="w-6 h-6" style={{ color }} />;
  };

  const getStatusIcon = () => {
    if (type === 'demand') {
      return <TrendingUp className="w-5 h-5 text-green-400" />;
    }
    return <CheckCircle className="w-5 h-5 text-green-400" />;
  };

  return (
    <motion.div
      className="relative w-80 h-80 cursor-pointer"
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      whileHover={{ scale: 1.05 }}
      transition={{ duration: 0.3 }}
    >
      {/* Outer glow effect */}
      <div 
        className="absolute inset-0 rounded-full opacity-20"
        style={{
          background: `radial-gradient(circle, ${glowColor}40 0%, transparent 70%)`,
          filter: `blur(20px)`,
        }}
      />
      
      {/* Multiple concentric circles */}
      <CircularProgress
        progress={progress}
        size={320}
        strokeWidth={2}
        color={color}
        glowColor={glowColor}
        delay={0}
      />
      <CircularProgress
        progress={progress * 0.8}
        size={280}
        strokeWidth={1.5}
        color={color}
        glowColor={glowColor}
        delay={0.2}
      />
      <CircularProgress
        progress={progress * 0.6}
        size={240}
        strokeWidth={1}
        color={color}
        glowColor={glowColor}
        delay={0.4}
      />
      <CircularProgress
        progress={progress * 0.4}
        size={200}
        strokeWidth={0.8}
        color={color}
        glowColor={glowColor}
        delay={0.6}
      />

      {/* Directional arrows for efficiency circle */}
      {type === 'efficiency' && (
        <>
          {[0, 60, 120, 180, 240, 300].map((rotation, index) => (
            <motion.div
              key={index}
              className="absolute w-4 h-4"
              style={{
                top: '50%',
                left: '50%',
                transformOrigin: '50% 50%',
              }}
              animate={{
                rotate: rotation,
                x: '-50%',
                y: '-140px',
              }}
              transition={{
                duration: 0.5,
                delay: index * 0.1,
              }}
            >
              <div 
                className="w-0 h-0 border-l-2 border-r-2 border-b-4 border-transparent"
                style={{ borderBottomColor: color }}
              />
            </motion.div>
          ))}
        </>
      )}

      {/* Central content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        {/* Status indicator and label */}
        <div className="flex items-center gap-2 mb-2">
          {getStatusIcon()}
          <span className="text-gray-300 text-sm tracking-wider uppercase">
            {label}
          </span>
        </div>

        {/* Main value */}
        <motion.div
          className="mb-4"
          style={{ color }}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.8, delay: 1 }}
        >
          <motion.span
            className="text-5xl tracking-tight"
            animate={{ opacity: isHovered ? 0.8 : 1 }}
            style={{
              textShadow: `0 0 20px ${glowColor}`,
              fontVariantNumeric: 'tabular-nums',
            }}
          >
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 1.2 }}
            >
              {formatValue(animatedValue)}
            </motion.span>
          </motion.span>
        </motion.div>

        {/* Sublabel */}
        <div className="flex items-center gap-2">
          {getIcon()}
          <span className="text-gray-400 text-sm tracking-wider uppercase">
            {sublabel}
          </span>
        </div>

        {/* Interactive pulse effect */}
        {isHovered && (
          <motion.div
            className="absolute inset-0 rounded-full border-2 opacity-40"
            style={{ borderColor: color }}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ 
              scale: [0.8, 1.2, 0.8], 
              opacity: [0, 0.4, 0] 
            }}
            transition={{ 
              duration: 2, 
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        )}
      </div>
    </motion.div>
  );
}